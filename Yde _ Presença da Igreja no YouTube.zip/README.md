
  # Yde | Presença da Igreja no YouTube

  This is a code bundle for Yde | Presença da Igreja no YouTube. The original project is available at https://www.figma.com/design/AwIqml7EFYBGnuxCpnckGW/Yde-%7C-Presen%C3%A7a-da-Igreja-no-YouTube.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  